This folder contains the main html file
TheNeighbourhood

and all of its resources, to view the main page, open The Neighbourhood file
Do not remove, rename, or delete any of the files in this folder, it will break the links and ruin the code, 
if you would like to get rid of any files in the folder just delete the folder in it entirety.